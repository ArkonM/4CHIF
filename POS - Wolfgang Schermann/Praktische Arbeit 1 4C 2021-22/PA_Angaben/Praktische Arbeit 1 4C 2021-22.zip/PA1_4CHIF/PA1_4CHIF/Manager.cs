﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA1_4CHIF
{
    class Manager
    {
        public static Carwash wash { get; set; }

        public void manage()
        {

        }

    }
}
