﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PA1N_4C
{
    class Car
    {
        public int id;
        static Random random = new Random();
        public static Bridge b { get; set; }
        public bool dir;
        public double weight;

        public Car(int id)
        {
            this.id = id;
        }

        public void drive()
        {
            b.cross(this);
        }

    }
}
