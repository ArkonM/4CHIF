﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PA1N_4C
{
    class VipBridge : Bridge
    {
        public VipBridge()
        {
            
        }


        public override void cross(Car c)
        {
            Console.Out.WriteLine("Auto {0} fährt von {1} auf die Brücke", c.id, (c.dir) ? "Westen" : "Osten");
            Thread.Sleep(1000);
            Console.Out.WriteLine("Auto {0} verlässt die Brücke", c.id);
        }
    }
}
