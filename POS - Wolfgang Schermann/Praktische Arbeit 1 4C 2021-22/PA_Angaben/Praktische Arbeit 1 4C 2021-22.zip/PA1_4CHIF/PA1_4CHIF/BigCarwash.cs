﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA1_4CHIF
{
    class BigCarwash : Carwash
    {
        public override void wash(Car c)
        {

        }
    }
}
