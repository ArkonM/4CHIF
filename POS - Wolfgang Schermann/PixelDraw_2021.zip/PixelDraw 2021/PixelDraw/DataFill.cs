﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;

namespace PixelDraw
{
    class DataFill
    {

        public int X { get; set; }
        public int Y { get; set; }
        public Color oldColor { get; set; }
        public Color newColor { get; set; }


    }
}
