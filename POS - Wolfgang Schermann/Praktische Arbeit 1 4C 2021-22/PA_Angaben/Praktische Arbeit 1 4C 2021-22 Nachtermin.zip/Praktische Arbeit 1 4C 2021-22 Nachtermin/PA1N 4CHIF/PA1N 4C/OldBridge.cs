﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PA1N_4C
{
    class OldBridge : Bridge
    {

        public OldBridge()
        {
        }


        public override void cross(Car c)
        { 
            Console.Out.WriteLine("Auto {0} fährt von {1} mit einem Gewicht von {2:F2} auf die Brücke", c.id, (c.dir) ? "Westen" : "Osten", c.weight);
            //Console.Out.WriteLine("Gesamtgewicht: {0:F2}", current);
            Thread.Sleep(1000);
            Console.Out.WriteLine("Auto {0} verlässt die Brücke", c.id);
        }
    }
}
